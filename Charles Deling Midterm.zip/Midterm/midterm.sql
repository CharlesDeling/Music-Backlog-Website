-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 23, 2023 at 05:48 PM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `midterm`
--

-- --------------------------------------------------------

--
-- Table structure for table `songs`
--

DROP TABLE IF EXISTS `songs`;
CREATE TABLE IF NOT EXISTS `songs` (
  `artist_name` text NOT NULL,
  `album_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `song_name` text NOT NULL,
  `song_genre` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `song_link` text NOT NULL,
  `have_listened` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `songs`
--

INSERT INTO `songs` (`artist_name`, `album_name`, `song_name`, `song_genre`, `song_link`, `have_listened`) VALUES
('Native Construct', 'Quiet World', 'Mute', 'Progressive Metal', 'https://music.youtube.com/watch?v=irIJgd9FnbQ&si=PSY8Z81_C2x7FBn4', 0),
('Native Construct', 'Quiet World', 'The Spark of the Archon', 'Progressive Metal', 'https://music.youtube.com/watch?v=9zUsR7wsUQM&si=Nia4AVwIauq9wuBU', 0),
('Native Construct', 'Quiet World', 'Passage', 'Progressive Metal', 'https://music.youtube.com/watch?v=u0EKGycdXFo&si=Dq3gLV8rsxXTmS0D', 0),
('Native Construct', 'Quiet World', 'Your Familiar Face', 'Progressive Metal', 'https://music.youtube.com/watch?v=AHoAQRpTFw0&si=4SJXL_bzpcGK9bzX', 0),
('Native Construct', 'Quiet World', 'Come Hell or High Water', 'Progressive Metal', 'https://music.youtube.com/watch?v=i8aOfLaFhY8&si=9QOurOOO8gRfgAdS', 0),
('Native Construct', 'Quiet World', 'Chromatic Lights', 'Progressive Metal', 'https://music.youtube.com/watch?v=4AN-P4tH0YQ&si=O2ah_spJDxiQ2OdS', 0),
('Native Construct', 'Quiet World', 'Chromatic Aberration', 'Progressive Metal', 'https://music.youtube.com/watch?v=K3ZXHsAoaN0&si=278t-YtImcgp90N6', 0),
('Periphery', 'Periphery II', 'Muramasa', 'Djent', 'https://music.youtube.com/watch?v=zGT1VuHt5ck&si=6TXrajYKvmWl3G-1', 0),
('Periphery', 'Periphery II', 'Have a Blast', 'Djent', 'https://music.youtube.com/watch?v=RjOo4uO74jA&si=VhG1qB57JVYiTNXb', 0),
('Periphery', 'Periphery II', 'Facepalm Mute', 'Djent', 'https://music.youtube.com/watch?v=0MK7T-X-t-8&si=v4B7rR2k167hP3lo', 0),
('Periphery', 'Periphery II', 'Ji', 'Djent', 'https://music.youtube.com/watch?v=g96NLNM-jAs&si=42lAkQnrQH5gAHQ0', 0),
('Periphery', 'Periphery II', 'Scarlet', 'Djent', 'https://music.youtube.com/watch?v=dLA4KLhe-e0&si=-AJEUIMWtNs-1qnq', 0),
('Periphery', 'Periphery II', 'Luck As A Constant', 'Djent', 'https://music.youtube.com/watch?v=f9Q8RI6xycY&si=bnc2tQpEFnWDs-g4', 0),
('Periphery', 'Periphery II', 'Ragnarok', 'Djent', 'https://music.youtube.com/watch?v=k3Ziiq5-WoA&si=opji6uUUdSRRAsod', 0),
('Periphery', 'Periphery II', 'The Gods Must Be Crazy!', 'Djent', 'https://music.youtube.com/watch?v=8se8bNe3FeU&si=8qReGNQYw9v69rYE', 0),
('Periphery', 'Periphery II', 'Make Total Destroy', 'Djent', 'https://music.youtube.com/watch?v=rxIQPF5Qy30&si=pcxaaEv8UV17MgB7', 0),
('Periphery', 'Periphery II', 'Erised', 'Djent', 'https://music.youtube.com/watch?v=B7uW50kL5uw&si=nkLHee1R9tmCzV29', 0),
('Periphery', 'Periphery II', 'Epoch', 'Djent', 'https://music.youtube.com/watch?v=Myv1sO-IqLU&si=xUii0hxPRS82kL1s', 0),
('Periphery', 'Periphery II', 'Froggin Bullfish', 'Djent', 'https://music.youtube.com/watch?v=y3QsTGT7ryo&si=jKcHCF6Mi8xh5j0b', 0),
('Periphery', 'Periphery II', 'Mile Zero', 'Djent', 'https://music.youtube.com/watch?v=YAaH1_p7Uwo&si=B_-rCz9fF7rZp5RJ', 0),
('Periphery', 'Periphery II', 'Masamune', 'Djent', 'https://music.youtube.com/watch?v=kTcAh-YYHqc&si=45jL-4bDuqXOP5aS', 0),
('Periphery', 'Periphery III: Select Difficulty', 'The Price Is Wrong', 'Djent', 'https://music.youtube.com/watch?v=uGs0bMiWlWo&si=szm8aBRBaa3oHU-M', 0),
('Periphery', 'Periphery III: Select Difficulty', 'Motormouth', 'Djent', 'https://music.youtube.com/watch?v=hec32qaOYFo&si=7cXrZX-gcaVK0Kaq', 0),
('Periphery', 'Periphery III: Select Difficulty', 'Marigold', 'Djent', 'https://music.youtube.com/watch?v=VizjMEe0agI&si=SpXD4bIu5ix71mku', 0),
('Periphery', 'Periphery III: Select Difficulty', 'The Way the News Goes...', 'Djent', 'https://music.youtube.com/watch?v=ZP9ee78fu74&si=GGM8mY_8i-qygxym', 0),
('Periphery', 'Periphery III: Select Difficulty', 'Remain Indoors', 'Djent', 'https://music.youtube.com/watch?v=q1NLR_5KUV0&si=ZXIBkI8w9VVjMivs', 0),
('Periphery', 'Periphery III: Select Difficulty', 'Habitual Line-Stepper', 'Djent', 'https://music.youtube.com/watch?v=VNsmeeYe_LY&si=R_K9s-SuDFNQtKVG', 0),
('Periphery', 'Periphery III: Select Difficulty', 'Flatline', 'Djent', 'https://music.youtube.com/watch?v=4n4aM618xjk&si=aXX50iPr1lEeNPCy', 0),
('Periphery', 'Periphery III: Select Difficulty', 'Absolomb', 'Djent', 'https://music.youtube.com/watch?v=ZTbOrl3REXs&si=CBmJ2KKJf85PUmVh', 0),
('Periphery', 'Periphery III: Select Difficulty', 'Catch Fire', 'Djent', 'https://music.youtube.com/watch?v=l9zd0GRR5mw&si=aU3g0JCUZK0VQUvC', 0),
('Periphery', 'Periphery III: Select Difficulty', 'Prayer Position', 'Djent', 'https://music.youtube.com/watch?v=Ysi445ws1t4&si=JOC08B-sT8Hf-SnM', 0),
('Periphery', 'Periphery III: Select Difficulty', 'Lune', 'Djent', 'https://music.youtube.com/watch?v=XPvMjmJJf2g&si=XlGleCukcN8ejEL5', 0),
('Rivers of Nihil', 'The Conscious Seed of Light', 'Terrestria I: Thaw', 'Technical Death Metal', 'https://music.youtube.com/watch?v=zehZ0ujvG5c&si=q2hMMJtsamU-c-vy', 0),
('Rivers of Nihil', 'The Conscious Seed of Light', 'Rain Eater', 'Technical Death Metal', 'https://music.youtube.com/watch?v=f4tGWDq3vjI&si=OoKhEcackw2JLPru', 0),
('Rivers of Nihil', 'The Conscious Seed of Light', 'Birth of the Omnisavior', 'Technical Death Metal', 'https://music.youtube.com/watch?v=dY4DpCv7j3U&si=N9G3ovvAYBgmryeK', 0),
('Rivers of Nihil', 'The Conscious Seed of Light', 'Soil & Seed', 'Technical Death Metal', 'https://music.youtube.com/watch?v=Lbb2rwiziuA&si=Bk6tMcOuvpPzGqxn', 0),
('Rivers of Nihil', 'The Conscious Seed of Light', 'Central Antheneum', 'Technical Death Metal', 'https://music.youtube.com/watch?v=24Fqg_bMcxU&si=f9fkboY6UUgbGVbH', 0),
('Rivers of Nihil', 'The Conscious Seed of Light', 'Mechanical Trees', 'Technical Death Metal', 'https://music.youtube.com/watch?v=3kqxyB2I6HE&si=8gmggto8NcNwfwbj', 0),
('Rivers of Nihil', 'The Conscious Seed of Light', 'Place of Serpents', 'Technical Death Metal', 'https://music.youtube.com/watch?v=sNKa2Kry6Ps&si=jukqQM8IsYLVZG-V', 0),
('Rivers of Nihil', 'The Conscious Seed of Light', 'Human Adaptation', 'Technical Death Metal', 'https://music.youtube.com/watch?v=V9O-Z86Wszc&si=WDc6Eqk-6faW4-Kt', 0),
('Rivers of Nihil', 'The Conscious Seed of Light', 'A Fertile Altar', 'Technical Death Metal', 'https://music.youtube.com/watch?v=V2tOFoe4D88&si=HCw6-4Ur2EDBNzB5', 0),
('Rivers of Nihil', 'The Conscious Seed of Light', 'Airless', 'Technical Death Metal', 'https://music.youtube.com/watch?v=ri6ugH735sw&si=9Y6xv59_FD7M2B0d', 0),
('Rivers of Nihil', 'Monarchy', 'Heirless', 'Technical Death Metal', 'https://music.youtube.com/watch?v=Mc6vMzbOUYw&si=5DQB3ptxN6opTzqB', 0),
('Rivers of Nihil', 'Monarchy', 'Perpetual Growth Machine', 'Technical Death Metal', 'https://music.youtube.com/watch?v=faAOeHTY2gU&si=s8m270Iv0CKDPiD5', 0),
('Rivers of Nihil', 'Monarchy', 'Reign of Dreams', 'Technical Death Metal', 'https://music.youtube.com/watch?v=i3HEQ-xqLao&si=nUHB5S3V4BjOhj1L', 0),
('Rivers of Nihil', 'Monarchy', 'Sand Baptism', 'Technical Death Metal', 'https://music.youtube.com/watch?v=BaT6qUGKLbg&si=n7LZIA4___loY-JM', 0),
('Rivers of Nihil', 'Monarchy', 'Ancestral, I', 'Technical Death Metal', 'https://music.youtube.com/watch?v=8Kz1WK544gc&si=8nAV4hL5HlCzcpDn', 0),
('Rivers of Nihil', 'Monarchy', 'Dehydrate', 'Technical Death Metal', 'https://music.youtube.com/watch?v=lXQpiVdIlfg&si=zmRW4sr8l4JIZQss', 0),
('Rivers of Nihil', 'Monarchy', 'Monarchy', 'Technical Death Metal', 'https://music.youtube.com/watch?v=QTeUOLNJf1Q&si=f5oK6CuqoFkxCjGL', 0),
('Rivers of Nihil', 'Monarchy', 'Terrestria II: Thrive', 'Technical Death Metal', 'https://music.youtube.com/watch?v=VVZQ4OT7SxE&si=ZAZVWxcux2y1rtPT', 0),
('Rivers of Nihil', 'Monarchy', 'Circles in the Sky', 'Technical Death Metal', 'https://music.youtube.com/watch?v=y8P02tzQ71E&si=2e3JfWfFiMkPLK7A', 0),
('Rivers of Nihil', 'Monarchy', 'Suntold', 'Technical Death Metal', 'https://music.youtube.com/watch?v=3dkc6tvpD1c&si=1r5TKep4AuaYukQc', 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
