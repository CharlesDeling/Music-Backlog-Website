<!DOCTYPE html>
<html lang="en">
<head> 
    <title>Charles' Music Backlog</title>
    <link rel="shortcut icon" href="images/icon.png">
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
    <?php
        include 'includes/connect.php';
    ?>
    <div class="body_container">
        <div class="nav_container"> 
            <h1 class="main_title">Add Songs</h1>
            <nav>
                <ul>
                    <li><a href="index.php" title="list">List</a></li>
                    <li><a href="add.php" title="add">Add Song</a></li>
                    <li><a href="update.php" title="update">Update Song</a></li>
                    <li><a href="delete.php" title="delete">Delete Song</a></li>
                </ul>
            </nav>
        </div> 
        <p class="instructions">Fill out the information on this page and click on the button labeled "ADD" in order to add a new song to the database:</p>
        <form class="form" action="addsong.php" method="POST">
            <label for="artist">Name of Artist:</label>
            <input type="text" id="artist" name="artist" required><br>
            <label for="album">Name of Album:</label>
            <input type="text" id="album" name="album" required><br>
            <label for="song">Name of Song:</label>
            <input type="text" id="song" name="song" required><br>
            <label for="genre">Genre:</label>
            <input type="text" id="genre" name="genre" required><br>
            <label for="link">Link for Song:</label>
            <input type="text" id="link" name="link" required><br>
            <input type="submit" value="Add">
        </form>
    </div>
</body>