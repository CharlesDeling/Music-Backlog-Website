<!DOCTYPE html>
<html lang="en">
<head> 
    <title>Charles' Music Backlog</title>
    <link rel="shortcut icon" href="images/icon.png">
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
    <?php
        include 'includes/connect.php';
    ?>
    <div class="body_container">
        <div class="nav_container"> 
            <h1 class="main_title">Update Songs</h1>
            <nav>
                <ul>
                    <li><a href="index.php" title="list">List</a></li>
                    <li><a href="add.php" title="add">Add Song</a></li>
                    <li><a href="update.php" title="update">Update Song</a></li>
                    <li><a href="delete.php" title="delete">Delete Song</a></li>
                </ul>
            </nav>
        </div> 
    <?php
	
	$searchArtist=$_POST['artist'];
    $searchSong=$_POST['song'];
    
    $artist=$_POST['uartist'];
	$album=$_POST['ualbum'];
    $song=$_POST['usong'];
    $genre=$_POST['ugenre'];
    $link=$_POST['ulink'];
    $listened=$_POST['listened'];
	session_start();
	
	$hostname="localhost";
	$username="root";
	$dBpassword="";
	$db="midterm";
	
    $mysqli = new mysqli($hostname, $username, $dBpassword, $db);

    /*if ($artist="") 
    {
        $sql="SELECT '".$artist."' := artist_name FROM songs WHERE artist_name='".$searchArtist."' AND song_name='".$searchSong."'";
        $mysqli->query($sql);
    }
    if ($album="") 
    {
        $sql="SELECT $album := album_name FROM songs WHERE artist_name=$searchArtist AND song_name=$searchSong";
        $mysqli->query($sql);
    }
    if ($song="") 
    {
        $mysqli->query("SELECT $song := song_name FROM songs WHERE artist_name=$searchArtist AND song_name=$searchSong");
    }
    if ($genre="") 
    {
        $mysqli->query("SELECT $genre := song_genre FROM songs WHERE artist_name=$searchArtist AND song_name=$searchSong");
    }
    if ($link="") 
    {
        $mysqli->query("SELECT $link := song_link FROM songs WHERE artist_name=$searchArtist AND song_name=$searchSong");
    }
    if ($listened="") 
    {
        $mysqli->query("SELECT $listened := have_listened FROM songs WHERE artist_name=$searchArtist AND song_name=$searchSong");
    }*/

	if (mysqli_connect_errno())
	{
		echo '<div class="alert alert-danger">Connect failed:$db<br>'.mysqli_connect_error().'</div>';
		die();
		exit();
	}
	else
	{
		$sql="UPDATE songs SET artist_name='".$artist."', album_name='".$album."', song_name='".$song."', song_genre='".$genre."', song_link='".$link."' WHERE artist_name='".$searchArtist."' AND song_name='".$searchSong."'";
		$mysqli->query($sql) or
			die("Something went wrong with $sql<br>".$mysqli->error);
        if ($listened=="yes") 
        {
            $sql="UPDATE songs SET have_listened=true WHERE artist_name='".$searchArtist."' AND song_name='".$searchSong."'";
		    $mysqli->query($sql) or
			    die("Something went wrong with $sql<br>".$mysqli->error);
        }
        if ($listened=="no") 
        {
            $sql="UPDATE songs SET have_listened=false WHERE artist_name='".$searchArtist."' AND song_name='".$searchSong."'";
		    $mysqli->query($sql) or
			    die("Something went wrong with $sql<br>".$mysqli->error);
        }
		echo "<p style='color:#404040; text-align: center; font-family: Georgia, 'Times New Roman', Times, serif;'> Song has been updated.</p><br>";
		exit();
	}

	exit();
    ?>  
    </div>
</body>
