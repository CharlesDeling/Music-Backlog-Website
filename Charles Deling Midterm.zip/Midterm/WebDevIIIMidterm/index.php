<!DOCTYPE html>
<html lang="en">
<head> 
    <title>Charles' Music Backlog</title>
    <link rel="shortcut icon" href="images/icon.png">
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
    <?php
        include 'includes/connect.php';
    ?>
    <div class="body_container">
        <div class="nav_container"> 
            <h1 class="main_title">Charles' Music Backlog</h1>
            <nav>
                <ul>
                    <li><a href="index.php" title="list">List</a></li>
                    <li><a href="add.php" title="add">Add Song</a></li>
                    <li><a href="update.php" title="update">Update Song</a></li>
                    <li><a href="delete.php" title="delete">Delete Song</a></li>
                </ul>
            </nav>
        </div> 
        <h2 class="sub_title">Need To Listen To:</h2>
            <?php
                echo "<table style='width: 100%;'>";
                echo "<tr>
                        <th>Artist</th>
                        <th>Album</th>
                        <th>Song</th>
                        <th>Genre</th>
                        <th>Link</th>
                      </tr>";
                $query = "SELECT * FROM songs WHERE have_listened=false";				
				$result = mysqli_query($conn, $query);	
				while($database = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
					echo "<tr>";
					echo "<td>" . $database['artist_name'] . "</td>";
					echo "<td>" . $database['album_name'] . "</td>";
					echo "<td>" . $database['song_name'] . "</td>";
                    echo "<td>" . $database['song_genre'] . "</td>";
                    echo "<td><a target='_blank' href='" . $database['song_link'] . "'>Click Here</a></td>";
					echo "</tr>";
				}
            ?>
        </table>
        <h2 class="sub_title">Have Listened To:</h2>
        <table style="width: 100%;">
            <tr>
                <th>Artist</th>
                <th>Album</th>
                <th>Song</th>
                <th>Genre</th>
                <th>Link</th>
            </tr>
            <?php
                $query = "SELECT * FROM songs WHERE have_listened=true";				
				$results = mysqli_query($conn, $query);	
				while($database = mysqli_fetch_array($results, MYSQLI_ASSOC)) {
					echo "<tr>";
					echo "<td>" . $database['artist_name'] . "</td>";
					echo "<td>" . $database['album_name'] . "</td>";
					echo "<td>" . $database['song_name'] . "</td>";
                    echo "<td>" . $database['song_genre'] . "</td>";
                    echo "<td><a target='_blank' href='" . $database['song_link'] . "'>Click Here</a></td>";
					echo "</tr>";
				}
            ?>
        </table>
    </div>
</body>