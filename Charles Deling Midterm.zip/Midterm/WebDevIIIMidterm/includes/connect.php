<?php

	$dbhost = 'localhost';
	$dbuser = 'root';
	$dbpass = '';
	$db = 'midterm';
	
	$conn = new mysqli($dbhost,$dbuser,$dbpass, $db); 

	// Check connection
	if ($conn->connect_error) {
		echo "Database failed to connect to: <span style='color:red;'>" . $dbhost . "</span>. " . $conn->connect_error, E_USER_ERROR . "<br>";
	} 
	
?>
