<!DOCTYPE html>
<html lang="en">
<head> 
    <title>Charles' Music Backlog</title>
    <link rel="shortcut icon" href="images/icon.png">
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
    <?php
        include 'includes/connect.php';
    ?>
    <div class="body_container">
        <div class="nav_container"> 
            <h1 class="main_title">Update Songs</h1>
            <nav>
                <ul>
                    <li><a href="index.php" title="list">List</a></li>
                    <li><a href="add.php" title="add">Add Song</a></li>
                    <li><a href="update.php" title="update">Update Song</a></li>
                    <li><a href="delete.php" title="delete">Delete Song</a></li>
                </ul>
            </nav>
        </div> 
        <p class="instructions">Enter the artist and the name of the song for the song would like to delete and click on the button labeled "DELETE" in order to delete the song from the database:</p>
        <form class="form" action="deletesong.php" method="POST">
            <label for="artist">Name of Artist:</label>
            <input type="text" id="artist" name="artist" required><br>
            <label for="song">Name for Song:</label>
            <input type="text" id="song" name="song" required><br><br>
            <input type="submit" value="Update">
        </form>
    </div>
</body>