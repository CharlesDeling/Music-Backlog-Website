<!DOCTYPE html>
<html lang="en">
<head> 
    <title>Charles' Music Backlog</title>
    <link rel="shortcut icon" href="images/icon.png">
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
    <?php
        include 'includes/connect.php';
    ?>
    <div class="body_container">
        <div class="nav_container"> 
            <h1 class="main_title">Update Songs</h1>
            <nav>
                <ul>
                    <li><a href="index.php" title="list">List</a></li>
                    <li><a href="add.php" title="add">Add Song</a></li>
                    <li><a href="update.php" title="update">Update Song</a></li>
                    <li><a href="delete.php" title="delete">Delete Song</a></li>
                </ul>
            </nav>
        </div> 
	<?php
	
	$artist=$_POST['artist'];
	$album=$_POST['album'];
    $song=$_POST['song'];
    $genre=$_POST['genre'];
    $link=$_POST['link'];
	session_start();
	
	$hostname="localhost";
	$username="root";
	$dBpassword="";
	$db="midterm";
	
	$mysqli = new mysqli($hostname, $username, $dBpassword, $db);
	if (mysqli_connect_errno())
	{
		echo '<div class="alert alert-danger">Connect failed:$db<br>'.mysqli_connect_error().'</div>';
		die();
		exit();
	}
	else
	{
		$sql="INSERT INTO songs VALUES ('".$artist."', '".$album."', '".$song."', '".$genre."', '".$link."', false)";
		$mysqli->query($sql) or
			die("Something went wrong with $sql<br>".$mysqli->error);
		echo "<p style='color:#404040; text-align: center; font-family: Georgia, 'Times New Roman', Times, serif;'> Song has been added.</p><br>";
		exit();
	}

	exit();
	?>
    </div>
</body>

