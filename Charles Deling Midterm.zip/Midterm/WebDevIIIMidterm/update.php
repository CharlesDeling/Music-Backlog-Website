<!DOCTYPE html>
<html lang="en">
<head> 
    <title>Charles' Music Backlog</title>
    <link rel="shortcut icon" href="images/icon.png">
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
    <?php
        include 'includes/connect.php';
    ?>
    <div class="body_container">
        <div class="nav_container"> 
            <h1 class="main_title">Update Songs</h1>
            <nav>
                <ul>
                    <li><a href="index.php" title="list">List</a></li>
                    <li><a href="add.php" title="add">Add Song</a></li>
                    <li><a href="update.php" title="update">Update Song</a></li>
                    <li><a href="delete.php" title="delete">Delete Song</a></li>
                </ul>
            </nav>
        </div> 
        <p class="instructions">Enter the artist and the name of the song for the song would like to update then fill out the information on this page and click on the button labeled "UPDATE" in order to update the value(s) for song in the database:</p>
        <form class="form" action="updatesong.php" method="POST">
            <label for="artist">Name of Artist:</label>
            <input type="text" id="artist" name="artist" required><br>
            <label for="song">Name for Song:</label>
            <input type="text" id="song" name="song" required><br><br>

            <label for="uartist">Updated Artist:</label>
            <input type="text" id="uartist" name="uartist" required><br>
            <label for="ualbum">Updated Album:</label>
            <input type="text" id="ualbum" name="ualbum" required><br>
            <label for="usong">Updated Song Name:</label>
            <input type="text" id="usong" name="usong" required><br>
            <label for="ugenre">Updated Genre:</label>
            <input type="text" id="ugenre" name="ugenre" required><br>
            <label for="ulink">Updated Link:</label>
            <input type="text" id="ulink" name="ulink" required><br>
            <label for="listened">Have you listened to this song? (yes or no)</label>
            <input type="text" id="listened" name="listened" required><br>
            <input type="submit" value="Update">
        </form>
    </div>
</body>